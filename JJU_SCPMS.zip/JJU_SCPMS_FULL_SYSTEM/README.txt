JJU SCPMS INSTALLATION:
1. Extract into htdocs/
2. Import jju_scpms.sql into phpMyAdmin
3. Login: admin / 123456
4. Enjoy!