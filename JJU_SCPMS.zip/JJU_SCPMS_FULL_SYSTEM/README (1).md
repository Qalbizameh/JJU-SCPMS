# JJU SCPMS

This is the **Jigjiga University Student Clinical Patient Management System**.

## Features:
- Role-based dashboards: Admin, Doctor, Lab, Pharmacy, Registration, Student
- Tab-based navigation in each module
- Multi-language support (EN, SO, AM)
- TailwindCSS + Font Awesome
- Dark/Light mode toggle
- Admin can manage users, upload students, view reports
- Responsive design for mobile and desktop

## Installation:

1. Extract into `htdocs/` if using XAMPP or Palapa/KSWEB
2. Import `sql/jju_scpms.sql` into phpMyAdmin
3. Edit `includes/db.php` if needed for your DB config
4. Visit `http://localhost/jju_scpms/public.php`

## Login (sample):
- **Admin**: admin / 123456

## License:
This project is for educational and institutional use.

© 2025 JJU SCPMS by Ahmed Aydrus Burale
